weather.metoffice
=================

Weather plugin for XBMC which fetches data from the UK Met Office.
